 <!-- Sidebar -->
<nav class="navbar-vertical navbar">
    <div class="nav-scroller">
        <!-- Brand logo -->
        <a class="navbar-brand">
            <img src="{{ \App\Models\SchoolSetting::get()->logo_url }}" alt="Logo Sekolah" />
            <span class="ms-2 fw-semibold text-white" style="font-size:16px; letter-spacing:0.5px;">
                {{ \App\Models\SchoolSetting::get()->school_name ?? 'SMKN 1 BENDO' }}
            </span>
        </a>
         <!-- Navbar nav -->
         <ul class="navbar-nav flex-column" id="sideNavbar">
             <li class="nav-item">
                 <a class="nav-link" href="{{ route('guru.home') }}">
                     <i data-feather="House door" class="bi bi-house-door icon-xs me-2"></i>Dashboard
                 </a>

             </li>
             <!-- Nav item -->
             <li class="nav-item">
                 <div class="navbar-heading">Manajemen</div>
             </li>
            </li>

            <li class="nav-item">
                <a class="nav-link has-arrow " href="{{ route('guru.presensi.index') }}"
                    aria-controls="navPages">
                    <i data-feather="File text" class="bi bi-file-text icon-xs me-2">
                    </i> Manajemen Absensi
                </a>

            <li class="nav-item">
                 <div class="navbar-heading">Absensi</div>
             </li>
            </li>
             <li class="nav-item">
                <a class="nav-link has-arrow " href="{{ route('guru.qrcode.index') }}"
                    aria-controls="navPages">
                    <i data-feather="QR code" class="bi bi-qr-code icon-xs me-2">
                    </i> Generate QR Code
                </a>

            <li class="nav-item">
                 <div class="navbar-heading">Laporan</div>
             </li>
            </li>
            <li class="nav-item">
                <a class="nav-link has-arrow " href="{{ route('guru.export-import.index') }}"
                    aria-controls="navPages">
                    <i data-feather="File earmark text" class="bi bi-file-earmark-text icon-xs me-2">
                    </i> Ekspor & Impor
                </a>

             
             <!-- <li class="nav-item">
                 <div class="navbar-heading">Pengaturan</div>
             </li>

            <li class="nav-item">
                <a class="nav-link has-arrow " href="#!"
                    aria-controls="navPages">
                    <i data-feather="Building" class="bi bi-building icon-xs me-2">
                    </i> Profil Sekolah
                </a>

            <li class="nav-item">
                 <a class="nav-link has-arrow  " href="#!"
                     data-bs-toggle="collapse" data-bs-target="#navAuthentication" aria-expanded="false"
                     aria-controls="navAuthentication">
                     <i data-feather="Lock" class="bi bi-lock icon-xs me-2">
                     </i> Autentikasi
                 </a>
                 <div id="navAuthentication" class="collapse  "
                     data-bs-parent="#sideNavbar">
                     <ul class="nav flex-column">
                         <li class="nav-item">
                             <a class="nav-link  "
                                 href="pages/sign-in.html"> Sign In</a>
                         </li>
                         <li class="nav-item">
                             <a class="nav-link  "
                                 href="pages/sign-up.html"> Sign Up</a>
                         </li>
                         <li class="nav-item">
                             <a class="nav-link  "
                                 href="pages/forget-password.html">
                                 Forget Password
                             </a>
                         </li>

                     </ul>
                 </div> -->
             </li>
         </ul>
     </div>
 </nav>
