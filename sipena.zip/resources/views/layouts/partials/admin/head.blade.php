<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Favicon icon-->
<!-- Favicon icon-->
<link rel="shortcut icon" type="image/png" href="{{ asset('admin_assets/images/brand/logo/logo_sekolah.png') }}">
<link rel="icon" type="image/png" href="{{ asset('admin_assets/images/brand/logo/logo_sekolah.png') }}">
<!-- Libs CSS -->
<link href="{{ asset('admin_assets/vendor/bootstrap-icons/font/bootstrap-icons.css') }}" rel="stylesheet">
<link href="{{ asset('admin_assets/vendor/dropzone/dist/dropzone.css') }}"  rel="stylesheet">
<link href="{{ asset('admin_assets/vendor/@mdi/font/css/materialdesignicons.min.css') }}" rel="stylesheet" />
<link href="{{ asset('admin_assets/vendor/prismjs/themes/prism-okaidia.css') }}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('admin_assets/css/theme.css') }}">
