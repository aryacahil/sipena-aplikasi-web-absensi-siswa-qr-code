<img src="{{ asset('admin_assets/images/brand/logo/logo_sekolah.png') }}" class="mb-2" alt="">
