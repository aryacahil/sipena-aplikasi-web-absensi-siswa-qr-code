<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.partials.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | SMKN 1 BENDO MAGETAN</title>
</head>

<body class="bg-light">
    <div id="db-wrapper">
            <?php echo $__env->make('layouts.partials.admin.navbar-vertical-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="page-content">
            <?php echo $__env->make('layouts.partials.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->make('layouts.partials.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH C:\laragon\www\sipena\resources\views/layouts/admin.blade.php ENDPATH**/ ?>