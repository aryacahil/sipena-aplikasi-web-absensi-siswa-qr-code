<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make("layouts.partials.admin.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Masuk | SMKN 1 BENDO MAGETAN</title>
</head>

<body class="bg-light">
  <!-- container -->
  <?php echo $__env->yieldContent('content'); ?>

  <!-- Scripts -->
  <?php echo $__env->make("layouts.partials.admin.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\sipena\resources\views/layouts/auth.blade.php ENDPATH**/ ?>