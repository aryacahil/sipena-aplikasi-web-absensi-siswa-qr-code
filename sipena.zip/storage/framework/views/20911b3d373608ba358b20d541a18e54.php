<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.partials.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | SMKN 1 BENDO MAGETAN</title>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="bg-light">
    <div id="db-wrapper">
        <?php echo $__env->make('layouts.partials.admin.navbar-vertical-siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="page-content">
            <?php echo $__env->make('layouts.partials.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->make('layouts.partials.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH C:\laragon\www\sipena\resources\views/layouts/siswa.blade.php ENDPATH**/ ?>